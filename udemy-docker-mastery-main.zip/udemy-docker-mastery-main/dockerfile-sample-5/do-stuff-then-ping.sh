#!/bin/sh

cat /etc/hosts
echo "ok i'm done, now let's ping'"

ping 8.8.8.8